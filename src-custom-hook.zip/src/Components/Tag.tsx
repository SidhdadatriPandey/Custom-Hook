import React from 'react'

const Tag = () => {
  return (
    <div>
      
    </div>
  )
}

export default Tag
